from scrapy import Item, Field


class ImageItem(Item):
    collection = table = 'images'
    
    id = Field()
    url = Field()
    title = Field()
    thumb = Field()
